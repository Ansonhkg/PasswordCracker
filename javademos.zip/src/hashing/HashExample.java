package hashing;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Hashing Example
 *
 * @author gardine1
 *
 */
public class HashExample {

    public static void main(String[] args) {

        try {
            // MessageDigest object is used to create hash. getInstance requires
            // the hashing algorithm to be defined.
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            String toHash = "password";
            // Convert the string into a byte array (getBytes()) and pass into
            // the digest object, which returns the hash as a byte array.
            byte[] hash = digest.digest(toHash.getBytes("UTF-8"));
            // using a string buffer, convert the byte array to a string
            // containing the hexadecimal representation
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if (hex.length() == 1)
                    hexString.append('0');
                hexString.append(hex);
            }
            // Print the output. Output string can be obtained by calling the
            // builders toString() method
            System.out.println(hexString.toString());
        } catch (NoSuchAlgorithmException e) {
            // Handle case where unknown algorithm is entered into the message
            // digest
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            // Catches possible exception on toHash.getBytes() call
            e.printStackTrace();
        }

    }

}
